using System;
using System.Windows.Forms;

namespace ClockExample
{
   public partial class Clock : Form
   {
      public Clock()
      {
         InitializeComponent();
      }
    }
}
