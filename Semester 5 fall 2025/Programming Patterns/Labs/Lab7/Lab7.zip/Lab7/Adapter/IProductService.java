public interface IProductService {
    public Product getProductById(int id);
}