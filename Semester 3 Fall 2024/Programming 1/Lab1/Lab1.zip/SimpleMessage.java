 /*
 * Cyril Efren Fabro
 * 6243515
 * Programming 1
 * 420-101-VA sect. 00005
 */
public class SimpleMessage {//This is the name of the class/program
    public static void main(String[] args) {//This is where you write and is the start of your code
        System.out.println("Jobs have a high salary\n" + 
                "You can have a remote job\n" + 
                "I want to try making a video game");//This command prints the reasons why I want to get into Computer Science
    }//this closes the program/code
}//This closes the class
