public class DataRepresentation {
    public static void main(String[] args) {
        System.out.println("If the world was ending, I'd wanna be next to you");
        System.out.println("727");
        System.out.println("3.14159");
    }
}
