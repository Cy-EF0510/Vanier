/*
 * Cyril Efren Fabro
 * 6243515
 * Programming 1
 * 420-101-VA sect. 00005
 */
public class HelloWorld {//This is the name of the class/program
    public static void main(String[] args) {//This is where you write and is the start of your code
        System.out.println("Cyril Efren Fabro");//This command prints my full name
    }//this closes the program/code
}//This closes the class